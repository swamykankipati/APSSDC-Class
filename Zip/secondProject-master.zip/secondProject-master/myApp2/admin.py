from django.contrib import admin
from myApp2.models import Student

# Register your models here.
admin.site.register(Student)
