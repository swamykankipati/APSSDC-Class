from django.apps import AppConfig


class Myapp2Config(AppConfig):
    name = 'myApp2'
